
package frc.robot.subsystems;



import frc.robot.Constants;

import com.revrobotics.CANSparkMax;
import com.revrobotics.EncoderType;
import com.revrobotics.CANSparkMaxLowLevel.MotorType;
import com.revrobotics.SparkMaxAlternateEncoder.Type;


import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class Winch extends SubsystemBase {
  CANSparkMax winch;
  XboxController xboxController;
  
  
  /** Creates a new Winch. */
  public Winch()
   {
    winch = new CANSparkMax(Constants.WINCH, MotorType.kBrushless);
 
    
    xboxController = new XboxController(2);
  
  }

  @Override
  public void periodic() {
 

  }
 

 

public void climb(double speed) {
  winch.set(speed);

}
public void stop() 
{
  winch.set(0);
}
}
