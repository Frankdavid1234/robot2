// Copyrigh// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import edu.wpi.first.wpilibj.DoubleSolenoid.Value;

/**
 * The Constants class provides a convenient place for teams to hold robot-wide numerical or boolean
 * constants. This class should not be used for any other purpose. All constants should be declared
 * globally (i.e. public static). Do not put anything functional in this class.
 *
 * <p>It is advised to statically import this class (or one of its inner classes) wherever the
 * constants are needed, to reduce verbosity.
 */
public final class Constants {
    
    public static final int LEFT1 = 6;
    public static final int LEFT2= 7;
    public static final int  RIGHT1= 8;
    public static final int  RIGHT2= 9;
     public static final int XboxController_LEFT_Y_AXIS = 1;
    public static final int XboxController_LEFT_X_AXIS = 0;
    public static final double DRIVETRAINSPEED = 0.7;
    public static final int DriveForwardTime = 3;
    public static final double AutonomousSpeed = 0.40;
    public static final int JoyStickNumber = 0;
    public static final int SHOOTER = 12;
    public static final double SHOOTER_SPEED = 0.80;
    public static final int INTAKE = 10;
    public static final int RIGHT_TRIGGER = 10;
    //public static final int CAMERA_RES_X = 1;
   // public static final int CAMERA_RES_Y = 2;
    public static final int WINCH = 13;
    public static final int WINCHSPEED = 1;
    public static double CLIMBSPEED = 1;
    public static final int Loader = 11;
    public static final Value REVERSE = Value.kReverse;
    public static final Value FORWARD = Value.kForward;
    public static final double LOADINGSPEED =0.50;
    public static final double SHOOTINGTIME = 5;
    public static final double AutonomousSHOTINGSpeed = 1;
    public static final double LoadTime = 3;
    public static final int CAMERA_RES_X = 240;
    public static final int CAMERA_RES_Y = 320 ;
    public static final double WINCHROTATION = 600;
    public static final double LOADINGTME = 1;
    //public static final String CAMERA_RES_Y = null;
    //public static final String CAMERA_RES_X = null;
    public static double INTAKE_SPEED = 1;
}
