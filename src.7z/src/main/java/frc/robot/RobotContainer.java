// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;






import edu.wpi.first.cameraserver.CameraServer;
import edu.wpi.first.cscore.UsbCamera;

//import edu.wpi.first.cameraserver.CameraServer;
//import edu.wpi.first.cscore.UsbCamera;

//import edu.wpi.first.cameraserver.CameraServer;
//import edu.wpi.first.cscore.UsbCamera;
import edu.wpi.first.wpilibj.GenericHID;

import edu.wpi.first.wpilibj2.command.*;
import edu.wpi.first.wpilibj.XboxController;
import frc.robot.commands.Armdown;
import frc.robot.commands.AutoLoad;
import frc.robot.commands.AutoShoot;
import frc.robot.commands.Climb;
import frc.robot.commands.DriveForwardTimed;
import frc.robot.commands.DriveWithJoysticks;
import frc.robot.commands.IntakeBall;
import frc.robot.commands.LiftBall;
import frc.robot.commands.LoadBall;
import frc.robot.commands.LowerPistons;
import frc.robot.commands.ShootBall;

import frc.robot.commands.TransmitionChange;
import frc.robot.subsystems.ArmPiton;
import frc.robot.subsystems.Intake;
import frc.robot.subsystems.Loader;
import frc.robot.subsystems.LoadingPistons;
import frc.robot.subsystems.Shooter;
import frc.robot.subsystems.Tankdrive;
import frc.robot.subsystems.Transmition;
import frc.robot.subsystems.TurnHelp;
import frc.robot.subsystems.Winch;
import edu.wpi.first.wpilibj2.command.button.JoystickButton;


/**
 * This class is where the bulk of the robot should be declared. Since Command-based is a
 * "declarative" paradigm, very little robot logic should actually be handled in the {@link Robot}
 * periodic methods (other than the scheduler calls). Instead, the structure of the robot (including
 * subsystems, commands, and button mappings) should be declared here.
 */
public class RobotContainer {
  // The robot's subsystems and commands are defined here...
private final AutoShoot autoShoot;
private final Tankdrive tankdrive;
private final DriveWithJoysticks driveWithJoysticks;
private final DriveForwardTimed driveForwardTimed;
public static XboxController driverJoystick;
private final Shooter shooter ;
private final  ShootBall shootball;
private final Intake intake;
private final IntakeBall intakeBall;
private final Winch winch;
private final Climb climb;
private final LoadBall loadBall;
private final Loader loader;
private final LiftBall liftBall;
private final LoadingPistons loadingPistons;
private final TurnHelp turnHelp;
private final LowerPistons lowerPistons;
private final Transmition transmision;
private final TransmitionChange transmitionChange;
private static XboxController xboxController;
private final ArmPiton armPiton ;
private final Armdown armdown;
private final AutoLoad autoLoad;


  /** The container for the robot. Contains subsystems, OI devices, and commands. */
  public RobotContainer() {
   tankdrive = new Tankdrive();
   driveWithJoysticks = new DriveWithJoysticks(tankdrive);
   driveWithJoysticks.addRequirements(tankdrive);
   tankdrive.setDefaultCommand(driveWithJoysticks);
   driveForwardTimed = new DriveForwardTimed(tankdrive);
   driveForwardTimed.addRequirements(tankdrive);

   driverJoystick =  new XboxController(Constants.JoyStickNumber);
   xboxController = new XboxController(2);
   shooter = new Shooter();
   shootball = new ShootBall(shooter);
   shootball.addRequirements(shooter);
   intake = new Intake();
   intakeBall = new IntakeBall(intake);
   intakeBall.addRequirements(intake);
   winch = new Winch();
   climb =new Climb(winch);
   climb.addRequirements(winch);
   loader= new Loader();
   loadBall = new LoadBall(loader);
   loadBall.addRequirements(loader);
    
   turnHelp = new TurnHelp();
   lowerPistons =new LowerPistons(turnHelp);
   lowerPistons.addRequirements(turnHelp);
   transmision = new Transmition();
   transmitionChange = new TransmitionChange(transmision);
   transmitionChange.addRequirements(transmision);
   autoShoot = new AutoShoot(shooter);
   autoShoot.addRequirements(shooter);
   armPiton = new ArmPiton();
   armdown = new Armdown(armPiton);
   armdown.addRequirements(armPiton);
   loadingPistons = new LoadingPistons();
   liftBall = new LiftBall(loadingPistons);
   liftBall.addRequirements(loadingPistons);
   autoLoad= new AutoLoad(loadingPistons);
   autoLoad.addRequirements(loadingPistons);
   
  


   
 UsbCamera camera2 = CameraServer.startAutomaticCapture();
 camera2.setResolution(Constants.CAMERA_RES_X,Constants.CAMERA_RES_Y);
  
 UsbCamera camera = CameraServer.startAutomaticCapture();
 camera.setResolution(Constants.CAMERA_RES_X,Constants.CAMERA_RES_Y);
        // Configure the button bindings
    configureButtonBindings();
  }

  /**
   * Use this method to define your button->command mappings. Buttons can be created by
   * instantiating a {@link GenericHID} or one of its subclasses ({@link
   * edu.wpi.first.sw.Joystick} or {@link XboxController}), and then passing it to a {@link
   * edu.wpi.first.wpilibj2.command.button.JoystickButton}.
   */
  private void configureButtonBindings() 
  {
    JoystickButton shootButton ;
    shootButton = new JoystickButton (driverJoystick,XboxController.Button.kRightBumper.value );
    shootButton.toggleWhenPressed(new ShootBall(shooter));  

    JoystickButton intakeButton;
    intakeButton= new JoystickButton(driverJoystick, XboxController.Button.kA.value);
    intakeButton.whileHeld(new IntakeBall(intake)); 
    JoystickButton winchButton;
    winchButton = new JoystickButton(xboxController,  XboxController.Button.kB.value);
    winchButton.whileHeld(new Climb(winch) );
    JoystickButton loadingButton;
    loadingButton = new JoystickButton(driverJoystick, XboxController.Button.kY.value);
    loadingButton.toggleWhenPressed(new LoadBall(loader));


   
  }
  

  

  


  

  /**
   * Use this to pass the autonomous command to the main {@link Robot} class.
   *
   * @return the command to run in autonomous
   */
  public Command getAutonomousCommand() {

    return new ParallelCommandGroup(driveForwardTimed,autoShoot,autoLoad);
  }
}
